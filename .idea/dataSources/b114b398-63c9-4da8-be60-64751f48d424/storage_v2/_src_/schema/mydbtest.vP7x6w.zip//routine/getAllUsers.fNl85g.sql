create
    definer = root@localhost procedure getAllUsers()
BEGIN
select * from users;
END;

