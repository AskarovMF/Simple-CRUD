create
    definer = root@localhost procedure getRecord(IN in_id int, OUT out_name varchar(20), OUT out_age int,
                                                 OUT out_email varchar(50), OUT out_birthday varchar(10))
BEGIN
   SELECT name, age, email, birthday
   INTO out_name, out_age, out_email, out_birthday
   FROM users where id = in_id;
END;

