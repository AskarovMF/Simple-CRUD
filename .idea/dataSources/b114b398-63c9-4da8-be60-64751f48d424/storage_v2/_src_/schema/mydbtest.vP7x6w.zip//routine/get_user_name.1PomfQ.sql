create
    definer = root@localhost function get_user_name(in_id int) returns varchar(200)
BEGIN
declare out_name varchar (200);

select name
into out_name
from users
where id = in_id;

RETURN out_name;
END;

